﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Example
{

    /// <summary>
    /// Represents an Order that contains a collection of items. ///
    /// Care should be taken to ensure that this class is immutable
    /// since it is sent to other systems for processing that should /// not be able to change it in any way.
    /// </summary>
    public class Order
    {
        private IList<IOrderItem> orderItems { get; } //immutable, only assignable by the constructor.
        /// <summary>
        /// Total order cost after the tax has been applied /// </summary>
        public decimal OrderTotal
        {
            get
            {
                decimal finalOrderTotal = 0;
                foreach (IOrderItem orderItem in orderItems)
                {
                    //each orderItem takes care of it's own taxes, if needed.
                    finalOrderTotal += orderItem.CalculateOrderItemTotalPrice(); 
                }
                //round to nearest penny.
                return Math.Round(finalOrderTotal,2);
            }
        }
        /// <summary>
        /// All items sorted by name (case-insensitive) /// </summary>
        public IReadOnlyList<Item> Items
        {
            get
            {
                //perform the sort;
                orderItems.OrderBy(i => i.Item.Name);


                List<Item> AllItems = new List<Item>();
                foreach (IOrderItem orderItem in orderItems)
                {
                    AllItems.AddRange(orderItem.GetAllItems());
                }
                return AllItems;

            }
        }
        /// <summary>
        /// Constructor, creates an order
        /// </summary>
        /// <param name="orderItems">Array of items to include in order</param> 
        public Order(IList<IOrderItem> orderItems)
        {
            this.orderItems = orderItems;
        }
    }
}
