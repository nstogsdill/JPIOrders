﻿using System;
using System.Collections.Generic;

namespace ECommerce.Example
{
    /// <summary>
    /// Represents a part or service that can be sold. ///
    /// Care should be taken to ensure that this class is immutable
    /// since it is sent to other systems for processing that should /// not be able to change it in any way.
    /// </summary>
    public class Item
    {
        /// <summary>
        /// Key
        /// </summary>
        public int Key { get; private set; }
        /// <summary>
        /// Name of the item
        /// </summary>
        public string Name { get; private set; } /// <summary>
                                                 /// Price for the item
                                                 /// </summary>
        public decimal Price { get; private set; }
        /// <summary>
        /// Constructor, creates an item
        /// </summary>
        /// <param name="key">Key</param>
        /// <param name="name">Name of item</param> /// <param name="price">Price</param>
        public Item(int key, string name, decimal price)
        {
            Key = key;
            Name = name;
            Price = price;
        }
    }
   

} 
