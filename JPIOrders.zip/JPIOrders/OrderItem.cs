﻿using System.Collections.Generic;

namespace ECommerce.Example
{
    //an interface defining the properties and methods an IOrderItem should contain.
    public interface IOrderItem
    {
        Item Item { get; set; }
        int Quantity { get; set; }
        decimal CalculateOrderItemTotalPrice(); //Calculates Item*Quantity (with or without tax), depending on the Concrete Class
        IList<Item> GetAllItems();
    }


    //A base IOrderItem class from which all IOrderItem sub-classes should derive (so if a change is made to the interface,
    //we don't have to manually change every child class.
    //this is ABSTRACT because we want to force all child-classes to implement their own version of "CalculateTotalPrice()"
    // some will add taxes, some will not... others in the future, who knows.... there might be multiple types of taxes.
    public abstract class OrderItem : IOrderItem
    {
        public Item Item { get; set; }
        public int Quantity { get; set; }
        public abstract decimal CalculateOrderItemTotalPrice();

        public IList<Item> GetAllItems()
        {
            IList<Item> allItems = new List<Item>();
            for(int i = 0;i<Quantity;i++)
            {
                allItems.Add(Item);
            }
            return allItems;
        }
    }

    //this item type IS taxable, make sure when the item is created, the tax-rate is passed in.
    public class MaterialOrderItem : OrderItem
    {
        public decimal TaxRate { get; set; }
        
        //constructor
        public  MaterialOrderItem(Item item, int quantity, decimal taxRate)
        {
            Item = item;
            TaxRate = taxRate;
            Quantity = quantity;
        }


        public override decimal CalculateOrderItemTotalPrice()
        {

            decimal totalPrice = Quantity * ( Item.Price + (Item.Price * TaxRate/100));
            return totalPrice;
        }
    }

    //this item type is NOT taxable
    public class ServiceOrderItem : OrderItem
    {
        public ServiceOrderItem(Item item, int quantity)
        {
            Item = item;
            Quantity = quantity;
        }

        public override decimal CalculateOrderItemTotalPrice()
        {
            return Item.Price * Quantity;
        }
    }

    //a class to make the creating of orderItems a little cleaner in the main program
    public class OrderItemsCreator
    {
        List<IOrderItem> orderItems { get; set; }

        public OrderItemsCreator()
        {
            orderItems = new List<IOrderItem>();
        }

        public void AddMaterialItem(Item item, int quantity, decimal taxRate)
        {
            orderItems.Add(new MaterialOrderItem(item, quantity, taxRate));
        }
        public void AddServiceItem(Item item,int quantity)
        {
            orderItems.Add(new ServiceOrderItem(item, quantity));
        }
        public IList<IOrderItem>GetOrderItems()
        {
            return orderItems;
        }
    }


}
