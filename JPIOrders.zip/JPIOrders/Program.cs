﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECommerce.Example
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting Up....");
            Console.WriteLine("");

            decimal standardTaxRate = 4.225M;
            decimal hazardMaterialsTaxRate = 11.233M;

            //create some items & services
            Item MacMouse = new Item(1, "Mac Mouse", 25.00M);
            Item PowerCable = new Item(2, "Power Cable", 10.00M);
            Item svcMouseCleaning = new Item(3, "Mouse cleaning Service", 2.50M);
            Item svcCableInstallation = new Item(4, "Cable installation - we'll plug it in for you.", 10.00M);
            Item svcComputerRestarting = new Item(5, "Computer Restarting - we'll restart your computer.", .99M);
            Item FetzerValve = new Item(6, "Fetzer valve with ball-bearings.", 34.99M);
            Item Plutonium = new Item(7, "Plutonium Rod", 1200.34M);
            Item MacMonitor = new Item(8, "Mac Monitor", 199.99M);

            //create an OrderItemsCreator to hold some of the items/services.
            OrderItemsCreator orderItemsCreator = new OrderItemsCreator();
            orderItemsCreator.AddMaterialItem(MacMonitor, 1, standardTaxRate);
            orderItemsCreator.AddMaterialItem(MacMouse, 4, standardTaxRate);
            orderItemsCreator.AddMaterialItem(FetzerValve, 5, standardTaxRate);
            orderItemsCreator.AddMaterialItem(Plutonium, 2, hazardMaterialsTaxRate);
            orderItemsCreator.AddServiceItem(svcCableInstallation, 6);
            orderItemsCreator.AddServiceItem(svcComputerRestarting, 3);


            //create the actual Order and pass it the just-created list of orderItems build by the orderItemsCreator.
            try
            {
                Console.WriteLine("");
                Order bigOrder = new Order(orderItemsCreator.GetOrderItems());

                //try to change the price of the Plutonium - gets compile error...
                //bigOrder.Items.Single(i => i.Name.Contains("Plutonium")).Price = 0;

                //write out the order contents to the console.
                Console.WriteLine("BIG Order Contains");
                foreach (Item i in bigOrder.Items)
                    Console.WriteLine(i.Name);
                Console.WriteLine("-----------------");
                Console.WriteLine("BIG Order Total Including Tax:" + bigOrder.OrderTotal);
            }
            catch(Exception ex)
            {
                Console.WriteLine("Could not create this order! Additional Information:" + ex.Message);
            }




            //create a small order to test tax versus no tax.
            try
            {
                Console.WriteLine("");
                orderItemsCreator = new OrderItemsCreator();
                orderItemsCreator.AddMaterialItem(PowerCable, 1, standardTaxRate);
                orderItemsCreator.AddServiceItem(svcCableInstallation, 1);

                Order littleOrder = new Order(orderItemsCreator.GetOrderItems());


                //write out the order contents to the console.
                Console.WriteLine("LITTLE Order Contains");
                foreach (Item i in littleOrder.Items)
                    Console.WriteLine(i.Name);
                Console.WriteLine("-----------------");
                
                Console.WriteLine("LITTLE Order Total Including Tax:" + littleOrder.OrderTotal);
            }
           catch(Exception ex)
            {
                Console.WriteLine("Could not create this order! Additional Information:" + ex.Message);
            }



            Console.WriteLine("");
            Console.WriteLine("Press any key to quit...");

            Console.ReadKey();

        }

    }






}
